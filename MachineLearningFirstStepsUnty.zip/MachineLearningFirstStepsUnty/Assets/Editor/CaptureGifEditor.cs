//By Cale Bradbury - netgrind.net
//Toss in Assets/Editor
//Free for any use
//use to slow down unity for capturing frames for external software (gifcam, etc, scrubs only)
//export png sequence to assemble elsewhere (try imagemagick, photoshop)
//protip - right under the game tab there is a drop down where you can pick ratios and set absolute size in pixels.

// in the folder containing frames: ffmpeg -r 60 -f image2 -i frames/frame-%03d.png -f mp4 -q:v 0 -vcodec mpeg4 unity.mp4

using UnityEngine;
using System.Collections;
using UnityEditor;
using System.IO;
using System.Diagnostics;
using System.Threading;
using System;


[ExecuteInEditMode]
public class CaptureGifEditor : EditorWindow {

	public int time = 6;
	public int frameRate = 60;
	public int frameDelay = 1;
	public bool captureFrames = true;
	public int captureUpscale = 1;
	public string path = "/Users/Rob/Desktop/UnityFrames";
	public string folder = "";
	string frameFolder = "frames";
	string frameName = "frame-";
	
	int i = -1;
	int c=0;
	private bool playing = true;
	bool cancel = false;
	
	public static CaptureGifEditor window;
	
	
	[MenuItem("Edit/Capture Frames Window %_g")]
	static void Init () 
	{
		window = EditorWindow.GetWindow<CaptureGifEditor>();
	}
	
	[MenuItem("Edit/Capture Frames _c")]
	static void Capture() 
	{
		if(window){
			EditorApplication.isPlaying = true;
			window.capture();
		}
	}

	void Update()
	{
		if(cancel)
			i = 0;
		c--;
		if(c<=0){
			c = frameDelay;
			if(i>0){
				UnityEngine.Debug.Log("Captured frame "+((frameRate*time)-i)+"/"+(frameRate*time));
				EditorApplication.Step();
				if(captureFrames){
					string s = ""+((frameRate*time)-i);
					while(s.Length<3)s = "0"+s;
					//Application.CaptureScreenshot(path+"/"+folder+"/"+frameFolder+"/"+frameName+s+".png",captureUpscale);
					Application.CaptureScreenshot(path+"/"+frameFolder+"/"+frameName+s+".png",captureUpscale);
				}
				i--;
			}else if(i==-1){
				EditorApplication.Step();
				i--;
				EditorApplication.isPaused = !playing;
			}
		}
		
		if(i == 0){
			i--;
			UnityEngine.Debug.Log("Done!");
			//ExecuteCommand("ffmpeg -r 60 -f image2 -i "+path+"/"+frameName+"%03d.png -f mp4 -q:v 0 -vcodec mpeg4 -r 60 "+path+"/_unity.mp4");
			//ExecuteCommand("ffmpeg -r 60 -f image2 -i "+path+"/"+folder+"/"+frameFolder+"/"+frameName+"%03d.png -f mp4 -q:v 0 -vcodec mpeg4 -r 60 "+path+"/"+folder+"/unity.mp4");
		}
		cancel = false;
	}

	public void Cancel(){
		cancel = true;
	}

	public void capture(){
		//folder = "Take_" + System.DateTime.Now.ToString("yyyyMMddHHmmssffff");
		Directory.CreateDirectory(path+"/"/*+folder+"/"*/+frameFolder);
		playing = EditorApplication.isPlaying;
		EditorApplication.isPaused=true;
		i = (frameRate*time);
	}

	void OnGUI()
	{
		time = EditorGUILayout.IntField("Run Time", time);
		frameRate = EditorGUILayout.IntField("Frame Rate", frameRate);
		frameDelay = EditorGUILayout.IntField("Frame Delay", frameDelay);
		captureFrames = GUILayout.Toggle(captureFrames,"Capture Frames");
		if(captureFrames){
			captureUpscale = EditorGUILayout.IntField("Upscale", captureUpscale);
		}
		if(GUILayout.Button("Capture"))
		{
			capture();
		}
		if(GUILayout.Button("Cancel"))
		{
			Cancel();
		}
		/*if(GUILayout.Button("Test command line"))
		{
			ExecuteCommand("say -v Thomas fuck");
			ExecuteCommand("afplay /System/Library/Sounds/Blow.aiff");
			//ExecuteCommand("/usr/local/bin/ffmpeg -r 60 -f image2 -i "+path+"/"+folder+"/"+frameFolder+"/"+frameName+"%03d.png -f mp4 -q:v 0 -vcodec mpeg4 -r 60 "+path+"/"+folder+"/unity.mp4");
			
		}*/
	}
	
	/*public void ExecuteCommandThreaded(string command){
		UnityEngine.Debug.Log(command);
		Thread thread = new Thread(delegate () {ExecuteCommand(command);});
		thread.Start();
	}
	
	public void ExecuteCommand(string command)
	{
		UnityEngine.Debug.Log(command);
		try{
			Process proc = new System.Diagnostics.Process ();
			proc.StartInfo.FileName = "/bin/bash";//"/bin/bash";
			proc.StartInfo.Arguments = "-c \" " + command + " \"";
			proc.StartInfo.WorkingDirectory = path;
			proc.StartInfo.UseShellExecute = false;
			proc.StartInfo.RedirectStandardOutput = true;
			//proc.StartInfo.CreateNoWindow = false;
			proc.Start();
		}
		catch(Exception e) {
			UnityEngine.Debug.Log ("An error occurred");
			UnityEngine.Debug.Log ("Error: "+e);
		}
	}*/
}